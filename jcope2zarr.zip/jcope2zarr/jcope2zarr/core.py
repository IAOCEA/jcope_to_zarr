from __future__ import annotations
import io
import re
import gzip
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

import fsspec
import numpy as np
import xarray as xr
import zarr
from numcodecs import Blosc

# -----------------------------
# CTL parsing
# -----------------------------

def _split(line: str) -> List[str]:
    return re.split(r"\s+", line.strip())

def parse_ctl(ctl_path: str) -> Dict:
    txt = Path(ctl_path).read_text(encoding="utf-8", errors="ignore").splitlines()
    # Remove comments starting with *; also strip trailing inline comments
    lines = [re.sub(r"\*.*$", "", L).strip() for L in txt]
    lines = [L for L in lines if L]

    info = {
        "path": str(ctl_path),
        "dset": None,
        "undef": None,
        "options": [],
        "xdef": None,
        "ydef": None,
        "zdef": None,
        "tdef": None,
        "vars": [],  # list of (name, nlev, desc)
    }

    it = iter(lines)
    for line in it:
        low = line.lower()
        if low.startswith("dset"):
            m = re.match(r"dset\s+(.+)$", line, flags=re.I)
            if m:
                info["dset"] = m.group(1).strip().strip('"').strip("'")
        elif low.startswith("undef"):
            parts = _split(line)
            if len(parts) >= 2:
                try:
                    info["undef"] = float(parts[1])
                except Exception:
                    pass
        elif low.startswith("options"):
            parts = _split(line)
            info["options"] = [p.lower() for p in parts[1:]]
        elif low.startswith("xdef"):
            info["xdef"] = _parse_axis_def(line, it)
        elif low.startswith("ydef"):
            info["ydef"] = _parse_axis_def(line, it)
        elif low.startswith("zdef"):
            info["zdef"] = _parse_axis_def(line, it)
        elif low.startswith("tdef"):
            info["tdef"] = _parse_tdef(line)
        elif low.startswith("vars"):
            while True:
                vline = next(it)
                if vline.lower().startswith("endvars"):
                    break
                toks = _split(vline)
                if len(toks) >= 2:
                    name = toks[0]
                    try:
                        nlev = int(toks[1])
                    except Exception:
                        nlev = 1
                    desc = " ".join(toks[2:]) if len(toks) > 2 else ""
                    info["vars"].append((name, nlev, desc))
    return info

def _parse_axis_def(first_line: str, it) -> Dict:
    parts = _split(first_line)
    n = int(parts[1])
    typ = parts[2].lower()
    if typ == "linear":
        v0 = float(parts[3]); dv = float(parts[4])
        vals = v0 + dv * np.arange(n, dtype=np.float64)
        return {"n": n, "type": "linear", "vals": vals}
    elif typ == "levels":
        remain = " ".join(parts[3:])
        while len(re.findall(r"[-+0-9.eE]+", remain)) < n:
            try:
                remain += " " + next(it)
            except StopIteration:
                break
        nums = re.findall(r"[-+0-9.eE]+", remain)
        vals = np.array(list(map(float, nums[:n])), dtype=np.float64)
        return {"n": n, "type": "levels", "vals": vals}
    else:
        raise ValueError(f"Unsupported axis type: {typ}")

_MON = {"jan":1, "feb":2, "mar":3, "apr":4, "may":5, "jun":6,
        "jul":7, "aug":8, "sep":9, "oct":10, "nov":11, "dec":12}

def _parse_tdef(line: str) -> Dict:
    parts = _split(line)
    n = int(parts[1]); typ = parts[2].lower()
    if typ == "linear":
        start = parts[3]
        dt = parts[4] if len(parts) > 4 else "1hr"
        return {"n": n, "type": "linear", "start": start, "dt": dt}
    elif typ == "levels":
        remain = " ".join(parts[3:])
        toks = re.findall(r"[^\s]+", remain)
        return {"n": n, "type": "levels", "levels": toks[:n]}
    else:
        raise ValueError(f"Unsupported TDEF type: {typ}")

# -----------------------------
# Helpers
# -----------------------------

def guess_time_from_filename(path: str) -> np.ndarray:
    """
    Infer a single timestamp from filename:
     - 12 digits: YYYYMMDDHHMM
     - 10 digits: YYYYMMDDHH
     -  8 digits: YYYYMMDD
    """
    name = Path(path).stem
    m = (re.search(r"(\d{12})$", name) or re.search(r"(\d{10})$", name) or
         re.search(r"(\d{8})$", name) or re.search(r"(\d{12})", name) or
         re.search(r"(\d{10})", name) or re.search(r"(\d{8})", name))
    if not m:
        return np.array([np.datetime64("1970-01-01T00:00:00")], dtype="datetime64[ns]")
    s = m.group(1)
    if len(s) == 12:
        dt = datetime.strptime(s, "%Y%m%d%H%M")
    elif len(s) == 10:
        dt = datetime.strptime(s, "%Y%m%d%H")
    else:
        dt = datetime.strptime(s, "%Y%m%d")
    return np.array([np.datetime64(dt)], dtype="datetime64[ns]")

def time_from_ctl_first(ctl: Dict) -> np.ndarray:
    """Create a single timestamp from TDEF start/levels (first entry)."""
    tdef = ctl.get("tdef")
    if not tdef:
        return np.array([np.datetime64("1970-01-01T00:00:00")], dtype="datetime64[ns]")
    if tdef["type"] == "linear":
        start = tdef.get("start","").lower()
        m = re.match(r"(?:(\d{1,2})z)?(\d{1,2})([a-z]{3})(\d{4})$", start)
        if m:
            hh = int(m.group(1) or 0); dd = int(m.group(2)); mon = _MON.get(m.group(3),1); yy = int(m.group(4))
            dt = datetime(yy, mon, dd, hh)
            return np.array([np.datetime64(dt)], dtype="datetime64[ns]")
        return np.array([np.datetime64("1970-01-01T00:00:00")], dtype="datetime64[ns]")
    elif tdef["type"] == "levels":
        tok = tdef.get("levels", ["19700101"])[0]
        # Try parse token like 00z25feb2021 or 25feb2021
        s = tok.strip().lower()
        m = re.match(r"(?:(\d{1,2})z)?(\d{1,2})([a-z]{3})(\d{4})$", s)
        if m:
            hh = int(m.group(1) or 0); dd = int(m.group(2)); mon = _MON.get(m.group(3),1); yy = int(m.group(4))
            dt = datetime(yy, mon, dd, hh)
            return np.array([np.datetime64(dt)], dtype="datetime64[ns]")
        return np.array([np.datetime64("1970-01-01T00:00:00")], dtype="datetime64[ns]")
    return np.array([np.datetime64("1970-01-01T00:00:00")], dtype="datetime64[ns]")

def _dtype_from_options(options: List[str]) -> np.dtype:
    endian = ">" if "big_endian" in options else "<" if "little_endian" in options else ">"
    return np.dtype(endian + "f4")

def _open_maybe_gzip(path: str):
    """
    Open local/remote file via fsspec. If .gz, wrap with gzip.GzipFile.
    Returns a binary file-like object with .read().
    """
    fo = fsspec.open(path, "rb").open()
    if str(path).lower().endswith(".gz"):
        return gzip.GzipFile(fileobj=fo)
    return fo

# -----------------------------
# Binary reading (flat & sequential)
# -----------------------------

def _read_flat_array(path: str, dtype: np.dtype, expected_count: int) -> np.ndarray:
    with _open_maybe_gzip(path) as f:
        raw = f.read()
    arr = np.frombuffer(raw, dtype=dtype, count=expected_count)
    if arr.size != expected_count:
        raise ValueError(f"Flat read: expected {expected_count} values, got {arr.size}. Check dtype/endianness/shape.")
    return arr

def _read_sequential_records(path: str, count_per_rec: int, nrec: int, dtype: np.dtype) -> np.ndarray:
    """
    Fortran unformatted sequential: [4-byte len][payload][4-byte len] per record.
    Record markers assumed little-endian int32 (gfortran on x86).
    Works on .gz too (streamed).
    """
    out = np.empty((nrec, count_per_rec), dtype=dtype.newbyteorder("="))
    with _open_maybe_gzip(path) as f:
        for i in range(nrec):
            lead = f.read(4)
            if len(lead) != 4:
                raise EOFError(f"EOF reading record {i} (lead marker).")
            reclen = int(np.frombuffer(lead, dtype="<i4")[0])
            payload = f.read(reclen)
            if len(payload) != reclen:
                raise EOFError(f"Short payload at record {i}.")
            trail = f.read(4)
            if len(trail) != 4:
                raise EOFError(f"EOF reading record {i} (trail marker).")
            arr = np.frombuffer(payload, dtype=dtype, count=count_per_rec)
            if arr.size != count_per_rec:
                raise ValueError(f"Record {i}: expected {count_per_rec} values, got {arr.size}.")
            out[i, :] = arr
    return out

def _get_var_nlev(ctl: dict, var_name: str) -> int:
    """Use nlev from VARS (per variable)."""
    for name, nlev, _ in ctl.get("vars", []):
        if name.lower() == var_name.lower():
            try:
                return max(1, int(nlev))
            except Exception:
                return 1
    return 1

def _factor_nxy(nxy: int, target_ratio: float | None = None) -> tuple[int, int]:
    """
    Factor nxy into (ny, nx). If target_ratio is provided, prefer ny/nx close to it,
    otherwise choose near-square.
    """
    best = (1, nxy, float("inf"))  # (ny, nx, score)
    import math
    r = int(math.sqrt(nxy))
    for ny in range(1, r + 1):
        if nxy % ny == 0:
            nx = nxy // ny
            score = abs((ny / nx) - target_ratio) if target_ratio else abs(nx - ny)
            if score < best[2]:
                best = (ny, nx, score)
    return best[0], best[1]

# -----------------------------
# High-level read -> Dataset
# -----------------------------

def read_single_bin_as_dataset(
    bin_path: str,
    ctl: Dict,
    var_name: Optional[str] = None,
    *,
    time_source: str = "filename",
    add_2d_latlon: bool = False,
) -> xr.Dataset:
    """
    Read single-variable / single-time GrADS binary and build an xarray Dataset
    with dims (time, sigma?, y, x). Time is inferred from filename (or from ctl if requested).
    """
    # variable name & nlev (VARS first)
    if var_name is None:
        var_name = ctl["vars"][0][0] if ctl.get("vars") else Path(bin_path).stem.split("_")[0]
    nz_var = _get_var_nlev(ctl, var_name)

    # options & dtype
    options = ctl.get("options", [])
    dtype = _dtype_from_options(options)
    undef = ctl.get("undef", 1.0e20)
    sequential = "sequential" in options

    # axis definitions
    nx_ctl = ctl["xdef"]["n"]; x_vals = ctl["xdef"]["vals"]
    ny_ctl = ctl["ydef"]["n"]; y_vals = ctl["ydef"]["vals"]
    target_ratio = ny_ctl / nx_ctl if nx_ctl > 0 else None

    # Read data
    if not sequential:
        with _open_maybe_gzip(bin_path) as f:
            raw = f.read()
        a = np.frombuffer(raw, dtype=dtype)
        total = a.size
        nxy = total // nz_var if nz_var > 1 else total
        expected_xy = nx_ctl * ny_ctl

        if nxy == expected_xy:
            ny, nx = ny_ctl, nx_ctl
        else:
            ny, nx = _factor_nxy(nxy, target_ratio=target_ratio)
            # coord fallback to index when sizes mismatch
            x_vals = np.arange(nx, dtype=np.float64)
            y_vals = np.arange(ny, dtype=np.float64)

        if nz_var == 1:
            arr = a.reshape((nx, ny), order="F").T                      # (ny, nx)
            dims = ("y", "x"); coords = {"y": y_vals, "x": x_vals}
        else:
            arr = a.reshape((nx, ny, nz_var), order="F").transpose(2, 1, 0)  # (nz, ny, nx)
            if ctl.get("zdef") and ctl["zdef"]["n"] == nz_var:
                sigma_vals = ctl["zdef"]["vals"]
            else:
                sigma_vals = np.arange(nz_var, dtype=np.float64)
            dims = ("sigma", "y", "x"); coords = {"sigma": sigma_vals, "y": y_vals, "x": x_vals}
    else:
        # sequential: assume 1 record per level (nx_ctl*ny_ctl each) and nz_var records
        recs = _read_sequential_records(bin_path, count_per_rec=nx_ctl*ny_ctl, nrec=nz_var, dtype=dtype)
        if nz_var == 1:
            arr = recs[0, :].reshape((nx_ctl, ny_ctl), order="F").T
            dims = ("y", "x"); coords = {"y": y_vals, "x": x_vals}
        else:
            planes = [recs[k, :].reshape((nx_ctl, ny_ctl), order="F").T[np.newaxis, ...] for k in range(nz_var)]
            arr = np.vstack(planes)
            sigma_vals = ctl["zdef"]["vals"] if ctl.get("zdef") and ctl["zdef"]["n"] == nz_var else np.arange(nz_var, dtype=np.float64)
            dims = ("sigma", "y", "x"); coords = {"sigma": sigma_vals, "y": y_vals, "x": x_vals}

    # mask UNDEF
    data = np.where(np.abs(arr) >= 0.9 * float(undef), np.nan, arr).astype(np.float32)

    # yrev/xrev
    if "yrev" in options:
        data = data[..., ::-1, :]
        coords["y"] = coords["y"][::-1]
    if "xrev" in options:
        data = data[..., :, ::-1]
        coords["x"] = coords["x"][::-1]

    # time
    if time_source == "ctl":
        tvals = time_from_ctl_first(ctl)
    else:
        tvals = guess_time_from_filename(bin_path)

    # Build dataset
    if len(dims) == 2:
        da = xr.DataArray(data[np.newaxis, ...], dims=("time", "y", "x"),
                          coords={"time": tvals, **coords}, name=var_name)
    else:
        da = xr.DataArray(data[np.newaxis, ...], dims=("time", "sigma", "y", "x"),
                          coords={"time": tvals, **coords}, name=var_name)

    ds = xr.Dataset({var_name: da})
    ds[var_name].attrs.update({"missing_value": np.float32(undef)})
    if "sigma" in ds.dims:
        ds["sigma"].attrs.update({"units": "1", "axis": "Z"})

    # Optional 2D lon/lat
    if add_2d_latlon and ("x" in ds.coords) and ("y" in ds.coords):
        # meshgrid -> (y,x)
        yy, xx = np.meshgrid(ds["y"].values, ds["x"].values, indexing="ij")
        ds["lat"] = (("y","x"), yy.astype(np.float32))
        ds["lon"] = (("y","x"), xx.astype(np.float32))
        ds["lat"].attrs["standard_name"] = "latitude"
        ds["lat"].attrs["units"] = "degrees_north"
        ds["lon"].attrs["standard_name"] = "longitude"
        ds["lon"].attrs["units"] = "degrees_east"

    ds.attrs.update({"source": Path(bin_path).name, "ctl": Path(ctl["path"]).name})
    return ds

# -----------------------------
# Zarr writing
# -----------------------------

def default_chunks_for(ds: xr.Dataset) -> Dict[str, int]:
    ch = {"time": 1}
    if "sigma" in ds.dims:
        ch["sigma"] = int(min(int(ds.dims["sigma"]), 16))
    if "y" in ds.dims:
        ch["y"] = int(min(int(ds.dims["y"]), 512))
    if "x" in ds.dims:
        ch["x"] = int(min(int(ds.dims["x"]), 512))
    return ch

def write_zarr(ds: xr.Dataset, out_path: str, chunks: Optional[Dict[str, int]] = None,
               append: bool = False, consolidate: bool = True) -> None:
    if chunks is None:
        chunks = default_chunks_for(ds)
    ds = ds.chunk({k: v for k, v in chunks.items() if k in ds.dims})

    # Prefer Blosc(zstd) if available
    compressor = Blosc(cname="zstd", clevel=3, shuffle=Blosc.SHUFFLE)
    encoding = {vn: {"compressor": compressor} for vn in ds.data_vars}

    mode = "a" if append else "w"
    append_dim = "time" if append else None
    store = out_path

    ds.to_zarr(store=store, mode=mode, encoding=encoding, append_dim=append_dim)
    if consolidate:
        zarr.convenience.consolidate_metadata(store)
