from __future__ import annotations
import argparse
import glob
from pathlib import Path
from typing import Dict, List, Optional

import fsspec

from .core import parse_ctl, read_single_bin_as_dataset, write_zarr

# Build a map from variable prefix -> ctl path
def build_ctl_map(ctl_dir: Path) -> Dict[str, Path]:
    mp: Dict[str, Path] = {}
    # 1) Direct name mapping like TT.ctl, ST.ctl, etc.
    for p in sorted(ctl_dir.glob("*.ctl")):
        stem_up = p.stem.upper()
        mp.setdefault(stem_up, p)

    # 2) Map VARS names within CTLs
    for p in sorted(ctl_dir.glob("*.ctl")):
        try:
            info = parse_ctl(str(p))
            for name, _, _ in info.get("vars", []):
                mp.setdefault(name.upper(), p)
        except Exception:
            pass
    return mp

def pick_ctl_for(bin_path: Path, ctl_map: Dict[str, Path]) -> Path:
    prefix = bin_path.stem.split("_")[0].upper()
    if prefix not in ctl_map and prefix.lower() == "depth":
        prefix = "DEPTH"
    if prefix in ctl_map:
        return ctl_map[prefix]
    for key in ["TT", "ST", "EGT", "UT", "VT", "DEPTH"]:
        if prefix.startswith(key) and key in ctl_map:
            return ctl_map[key]
    raise FileNotFoundError(f"No matching .ctl for '{bin_path.name}' (prefix '{prefix}'). Use --ctl-dir to point to CTLs.")

def parse_chunks(arg: Optional[str]):
    if not arg:
        return None
    parts = [p.strip() for p in arg.split(",")]
    keys = ["time", "sigma", "y", "x"]
    out = {}
    for k, p in zip(keys, parts):
        if p:
            out[k] = int(p)
    return out

def _expand_paths(pattern: str) -> List[Path]:
    # Local glob
    if "://" not in pattern:
        return [Path(p) for p in glob.glob(pattern)]
    # Remote via fsspec
    fs, _, paths = fsspec.get_fs_token_paths(pattern)
    if not paths:
        return []
    out = []
    for p in paths:
        if "*" in p or "?" in p:
            for q in fs.glob(p):
                out.append(Path(q))
        else:
            out.append(Path(p))
    return out

def main():
    ap = argparse.ArgumentParser(description="Convert JCOPE/JAMSTEC *.bin or *.bin.gz to Zarr (sigma kept as-is)")
    ap.add_argument("bins", nargs="+", help="Binary files (supports local/remote/glob)")
    ap.add_argument("--ctl-dir", default=".", help="Directory containing *.ctl files")
    ap.add_argument("--out", default=None, help="Output Zarr path. If omitted, each input writes <bin>.zarr")
    ap.add_argument("--append", action="store_true", help="Append to existing Zarr along time dimension")
    ap.add_argument("--chunks", default=None, help="Chunk sizes as 'time,sigma,y,x' (e.g., 1,16,512,512)")
    ap.add_argument("--time-source", choices=["filename", "ctl"], default="filename", help="Use time from filename (default) or from .ctl (first entry)")
    ap.add_argument("--add-2d-latlon", action="store_true", help="Also write 2D lon/lat variables derived from 1D coords")
    ap.add_argument("--no-consolidate", action="store_true", help="Do not consolidate Zarr metadata")
    args = ap.parse_args()

    # Expand inputs
    bin_files: List[Path] = []
    for pat in args.bins:
        bin_files.extend(_expand_paths(pat))
    if not bin_files:
        raise SystemExit("No input files matched.")

    ctl_map = build_ctl_map(Path(args.ctl_dir))
    chunks = parse_chunks(args.chunks)
    consolidate = not args.no_consolidate

    aggregate = args.out is not None and args.append

    if aggregate:
        out_path = args.out
        first = True
        for bp in sorted(bin_files):
            ctl_path = pick_ctl_for(bp, ctl_map)
            ds = read_single_bin_as_dataset(
                str(bp), parse_ctl(str(ctl_path)),
                time_source=args.time_source,
                add_2d_latlon=args.add_2d_latlon,
            )
            write_zarr(ds, out_path, chunks=chunks, append=not first, consolidate=consolidate)
            first = False
    else:
        for bp in sorted(bin_files):
            ctl_path = pick_ctl_for(bp, ctl_map)
            ds = read_single_bin_as_dataset(
                str(bp), parse_ctl(str(ctl_path)),
                time_source=args.time_source,
                add_2d_latlon=args.add_2d_latlon,
            )
            out_path = args.out or (str(bp) + ".zarr")
            write_zarr(ds, out_path, chunks=chunks, append=args.append, consolidate=consolidate)

if __name__ == "__main__":
    main()
