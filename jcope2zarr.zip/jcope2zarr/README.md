# jcope2zarr

Convert JCOPE/JAMSTEC Fortran (GrADS) binaries (`*.bin` or `*.bin.gz`) to **Zarr** while **keeping native sigma coordinates** (no vertical remapping).

- Parses `.ctl` (XDEF/YDEF/ZDEF/TDEF/OPTIONS), including `big_endian`, `little_endian`, `sequential`, `xrev`, `yrev`.
- Assumes **single-variable, single-time** per file (e.g., `TT_YYYYMMDDHHMM.bin`).
- Time is **inferred from filename** by default (you can switch to `.ctl` with `--time-source ctl`).
- Writes **Zarr** with dims `(time, sigma?, y, x)`. Missing values from `UNDEF` are masked to NaN.

## Install

```bash
pip install .
# dev mode
pip install -e .
```

## Usage

```bash
# Single file -> its own Zarr store
jcope2zarr TT_202102251600.bin --ctl-dir ./ --out TT_202102251600.zarr

# Gzip-compressed input
jcope2zarr TT_202102251600.bin.gz --ctl-dir ./ --out TT_202102251600.zarr

# Batch: each input to <bin>.zarr
jcope2zarr TT_*.bin --ctl-dir ./TT_ctls

# Append many times into one Zarr (time dimension)
jcope2zarr TT_*.bin --ctl-dir ./ --out TT.zarr --append

# Switch time source
jcope2zarr TT_*.bin --ctl-dir ./ --out TT.zarr --append --time-source ctl

# Add 2D lon/lat variables (mesh from 1D coords)
jcope2zarr TT_*.bin --ctl-dir ./ --out TT.zarr --append --add-2d-latlon

# Remote paths (s3/gs/http) via fsspec (install extras: pip install .[cloud])
jcope2zarr s3://bucket/path/TT_202102251600.bin --ctl-dir s3://bucket/ctls --out s3://bucket/out/TT.zarr --append
```

### Behavior

- If `nx*ny` in `.bin` **does not match** `.ctl`’s XDEF×YDEF, the reader **factors** the total element count to guess `(ny, nx)` (close to `.ctl` aspect ratio) and **falls back to index coordinates** for `x`/`y`.
- The variable’s **vertical levels** use **`VARS` nlev** (per-variable), *not* `ZDEF` global count. This ensures 2D EGT (nlev=1) is handled correctly even if the `.ctl` has `ZDEF 47`.
- For `OPTIONS sequential`, the file is read as **Fortran unformatted** records (one record per level).

## Requirements / Notes

- Python ≥ 3.9
- For cloud I/O, install extras: `pip install .[cloud]` (adds `s3fs`, `gcsfs`).
- Zarr compressor: Blosc(zstd). Adjust in code if needed.
